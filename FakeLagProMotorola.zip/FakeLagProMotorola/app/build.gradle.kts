plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fakelagpro.motorola"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fakelagpro.motorola"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
