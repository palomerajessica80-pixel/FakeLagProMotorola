package com.fakelagpro.motorola

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lagOn = false
    private var freezeOn = false
    private var teleportOn = false

    override fun onCreate() {
        super.onCreate()
        createNotification()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun createNotification() {
        val channelId = "fake_lag_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Panel flotante", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }.setContentTitle("Fake Lag Pro está activo")
            .setContentText("Panel visual flotante en ejecución")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(77, notification)
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "FL"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(220, 35, 65))
            setPadding(18, 14, 18, 14)
            setOnClickListener { togglePanel() }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 220
        }
        windowManager.addView(b, params)
        bubble = b
        makeDraggable(b, params)
    }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }
    }

    private fun togglePanel() {
        if (panel != null) {
            try { windowManager.removeView(panel) } catch (_: Exception) {}
            panel = null
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(Color.rgb(20, 24, 37))
        }
        val heading = label("FAKE LAG PRO", 20, Color.rgb(255, 65, 90))
        box.addView(heading)
        box.addView(label("SIMULADOR VISUAL • MOTOROLA", 10, Color.LTGRAY))
        box.addView(actionButton("FAKE LAG: OFF") {
            lagOn = !lagOn
            it.text = if (lagOn) "FAKE LAG: ON" else "FAKE LAG: OFF"
            it.setTextColor(if (lagOn) Color.GREEN else Color.WHITE)
        })
        box.addView(actionButton("TELETRANSPORTE: OFF") {
            teleportOn = !teleportOn
            it.text = if (teleportOn) "SALTO VISUAL: ON" else "TELETRANSPORTE: OFF"
            if (teleportOn) visualJump()
        })
        box.addView(actionButton("PARALIZADOR: OFF") {
            freezeOn = !freezeOn
            it.text = if (freezeOn) "EFECTO VISUAL: ON" else "PARALIZADOR: OFF"
            box.alpha = if (freezeOn) 0.65f else 1f
        })
        box.addView(actionButton("CERRAR PANEL") { togglePanel() })
        box.addView(label("Solo afecta este panel; no modifica el juego.", 10, Color.LTGRAY))

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 90
            y = 250
        }
        panelParams = p
        panel = box
        windowManager.addView(box, p)
        makeDraggable(box, p)
    }

    private fun visualJump() {
        val v = panel ?: return
        val p = panelParams ?: return
        val oldX = p.x
        val oldY = p.y
        p.x = oldX + 90
        p.y = oldY + 55
        windowManager.updateViewLayout(v, p)
        handler.postDelayed({
            if (panel === v) {
                p.x = oldX
                p.y = oldY
                try { windowManager.updateViewLayout(v, p) } catch (_: Exception) {}
            }
        }, 450)
    }

    private fun label(text: String, size: Int, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        setPadding(6, 8, 6, 8)
    }

    private fun actionButton(text: String, action: (TextView) -> Unit) =
        TextView(this).apply {
            this.text = text
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(12, 14, 12, 14)
            setBackgroundColor(Color.rgb(47, 55, 76))
            setOnClickListener { action(this) }
        }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { bubble?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        bubble = null
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
