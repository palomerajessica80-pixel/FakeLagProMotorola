package com.fakelagpro.motorola

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestOverlay = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showScreen()
    }

    private fun showScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF10131D.toInt())
        }

        val title = TextView(this).apply {
            text = "FAKE LAG PRO"
            textSize = 28f
            setTextColor(0xFFFF465D.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "MOTOROLA • ANDROID 15\nPanel flotante de simulación"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFFD6D9E2.toInt())
            setPadding(0, 12, 0, 28)
        }
        val start = Button(this).apply {
            text = "ACTIVAR MENÚ FLOTANTE"
            setOnClickListener { enableOverlay() }
        }
        val note = TextView(this).apply {
            text = "\nLos controles solo generan efectos visuales locales. No alteran Free Fire, la red ni a otros jugadores."
            textSize = 13f
            setTextColor(0xFFB6BDCE.toInt())
            gravity = Gravity.CENTER
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(start)
        root.addView(note)
        setContentView(root)
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, requestOverlay)
        } else {
            startOverlayService()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestOverlay && Settings.canDrawOverlays(this)) {
            startOverlayService()
        }
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        finish()
    }
}
