FAKE LAG PRO MOTOROLA — PROYECTO ANDROID

Compatibilidad objetivo: Android 15 / API 35.
Incluye: panel flotante, interruptores de simulación visual y botón flotante FL.

IMPORTANTE:
Los botones solo cambian estados y animaciones del panel de esta aplicación.
No provocan lag real de red, no controlan Free Fire y no teletransportan ni paralizan
personajes u otros jugadores.

CÓMO OBTENER EL APK SIN ANDROIDIDE:
1. Descomprime este ZIP.
2. Crea un repositorio en GitHub e inicia sesión.
3. Sube el contenido de esta carpeta al repositorio (la carpeta .github incluida).
4. Abre la pestaña Actions del repositorio.
5. Ejecuta "Build APK" (o espera a que termine el flujo automático).
6. Abre la ejecución terminada y descarga el artefacto
   "FakeLagProMotorola-debug".
7. Descomprime el artefacto y encontrarás app-debug.apk.

INSTALACIÓN:
1. Abre app-debug.apk en el Motorola.
2. Autoriza la instalación desde esa fuente si Android lo solicita.
3. Abre Fake Lag Pro Motorola.
4. Pulsa ACTIVAR MENÚ FLOTANTE.
5. Autoriza "Mostrar sobre otras aplicaciones".
6. Usa la burbuja FL para abrir/cerrar el panel.

Si Android muestra un aviso de notificaciones, permite las notificaciones para
mantener visible el servicio mientras el panel está activo.

Para cerrar el panel, abre el panel y pulsa CERRAR PANEL. Para detener por completo
el servicio, fuerza la detención de la aplicación desde Ajustes > Aplicaciones.
